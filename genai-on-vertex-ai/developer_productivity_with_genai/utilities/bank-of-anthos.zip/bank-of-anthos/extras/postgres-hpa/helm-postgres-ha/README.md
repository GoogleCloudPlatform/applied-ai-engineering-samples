# HA PostgreSQL configuration

This directory contains configuration for example HA PostgreSQL cluster

* `values.yaml` - PostgresQL Helm chart values ()