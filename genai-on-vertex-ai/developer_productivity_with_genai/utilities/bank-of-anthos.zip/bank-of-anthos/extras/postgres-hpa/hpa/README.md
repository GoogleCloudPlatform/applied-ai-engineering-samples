# Horizontal Pod Autoscaler (HPA) for GKE Autopilot

This directory contains HPA manifests
