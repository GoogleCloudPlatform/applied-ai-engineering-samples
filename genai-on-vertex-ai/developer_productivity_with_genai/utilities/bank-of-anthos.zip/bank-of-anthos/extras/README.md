# Extras

This directory contains a collection of varied optional scripts, samples, and extensions to Bank of Anthos.
The content of these extras do not necessarily follow the same standards as the mainline application,
and are not guaranteed to be fully up-to-date or to work well in conjunction with other extras.
By using these extras, you acknowledge that support in case of issues will be minimal.
